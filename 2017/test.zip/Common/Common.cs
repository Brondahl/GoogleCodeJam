﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Common
{
  public class Common
  {
    private static string folderPath = @"C:\Users\Brondahl\My Files\Programming\C#\VS Projects\GoogleCodeJam2017\";
      
    public static string[] ReadStringInput(string subFolderName, out int numberOfCases)
    {
      var lines = File.ReadAllLines(folderPath + subFolderName + @"\Data.in");
      numberOfCases = int.Parse(lines.First());
      return lines.Skip(1).ToArray();
    }

    public static int[] ReadIntInput(string fileName, out int numberOfCases)
    {
      var textLines = ReadStringInput(fileName, out numberOfCases);
      return textLines.Select(int.Parse).ToArray();
    }

    public static long[] ReadLongInput(string fileName, out int numberOfCases)
    {
      var textLines = ReadStringInput(fileName, out numberOfCases);
      return textLines.Select(long.Parse).ToArray();
    }

    public static void WriteOutput(string subFolderName, IEnumerable<string> lines)
    {
      File.WriteAllLines(folderPath + subFolderName + @"\Data.out", lines.ToArray());
    }


    public static IEnumerable<IEnumerable<string>> CaseLineForNFromFirstVal(IEnumerable<string> lines)
    {
      return CaseLineSplitter(lines, "0 -1", (NArray) => NArray.Single() + 1 );
    }

    public static IEnumerable<IEnumerable<string>> CaseLineForNFromFirstValPlusOne(IEnumerable<string> lines)
    {
      return CaseLineSplitter(lines, "0 -1", (NArray) => NArray.Single() + 2);
    }

    public static IEnumerable<IEnumerable<string>> CaseLineForNFromSecondVal(IEnumerable<string> lines)
    {
      return CaseLineSplitter(lines, "-1 0", (NArray) => NArray.Single() + 1);
    }

    public static IEnumerable<IEnumerable<string>> CaseLineSplitter(IEnumerable<string> lines, string firstLineFormat, Func<long[], long> numberOfLinesInACase)
    {
      return CaseLineSplitter(lines, firstLineFormat, (lineCount, args) => { return lineCount < numberOfLinesInACase(args) - 1; } );
    }

    public static IEnumerable<IEnumerable<string>> CaseLineSplitter(IEnumerable<string> lines, string firstLineFormat, Func<long, long[], bool> continueTest)
    {
      var firstLineFormatComponents = firstLineFormat.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(long.Parse).ToArray();
      var caseSet = new List<string>();
      long[] continueTestArgs = null;
      var currentLineCount = 0;
      
      foreach (var line in lines)
      {
        caseSet.Add(line);

        if (continueTestArgs == null)
        {
          var currentFirstLineValues = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(long.Parse).ToArray();
          var zippedValues = Enumerable.Zip(firstLineFormatComponents, currentFirstLineValues, (format, actual) => new KeyValuePair<long, long>(format, actual));
          continueTestArgs = zippedValues.Where(pair => pair.Key != -1).OrderBy(pair => pair.Key).Select(pair => pair.Value).ToArray();
        }

        // e.g. when N is 3, you'll want to return lines 0, 1, 2 & 3.
        // Thus you keep 'continue' on when count = 2, and stop when count = 3
        if (continueTest(currentLineCount, continueTestArgs))
        {
          currentLineCount++;
          continue;
        }

        // We've reached the end of the CaseSet.
        // Return this caseSet and reset.
        yield return caseSet.ToList();
        caseSet = new List<string>();
        continueTestArgs = null;
        currentLineCount = 0;
      }

    }

  }
}
