﻿using System;
using System.Linq;
using FluentAssertions;
using NUnit.Framework;

namespace Common
{
  [TestFixture]
  class Tests
  {
    [Test]
    public static void CaseLineForNFromFirstValTest()
    {
      var inputFile =
@"3
3 3
G??
?C?
??J
3 4
CODE
????
?JAM
2 2
CA
KE".Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList().Skip(1);

      var output = Common.CaseLineForNFromFirstVal(inputFile);

      output.Count().Should().Be(3);

      output.First().Count().Should().Be(4);
      output.Skip(1).First().Count().Should().Be(4);
      output.Skip(2).First().Count().Should().Be(3);

      output.First().Skip(1).First().Should().Be("G??");

      output.Skip(1).First().Skip(1).First().Should().Be("CODE");

      output.Skip(2).First().Skip(1).First().Should().Be("CA");
    }

    [Test]
    public static void CaseLineForNFromFirstValPlusOneTest()
    {
      var inputFile =
@"3
3 3
foo
G??
?C?
??J
3 4
bar
CODE
????
?JAM
2 2
baz
CA
KE".Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList().Skip(1);

      var output = Common.CaseLineForNFromFirstValPlusOne(inputFile);

      output.Count().Should().Be(3);

      output.First().Count().Should().Be(5);
      output.Skip(1).First().Count().Should().Be(5);
      output.Skip(2).First().Count().Should().Be(4);

      output.First().First().Should().Be("3 3");
      output.First().Skip(1).First().Should().Be("foo");
      output.First().Skip(2).First().Should().Be("G??");
      output.First().Skip(3).First().Should().Be("?C?");
      output.First().Skip(4).First().Should().Be("??J");

      output.Skip(1).First().First().Should().Be("3 4");
      output.Skip(1).First().Skip(1).First().Should().Be("bar");
      output.Skip(1).First().Skip(2).First().Should().Be("CODE");
      output.Skip(1).First().Skip(3).First().Should().Be("????");
      output.Skip(1).First().Skip(4).First().Should().Be("?JAM");
    }

    [Test]
    public static void CaseLineForNFromSecondVal()
    {
      var inputFile =
@"3
3 3
foo
?C?
??J
3 4
bar
CODE
????
?JAM
4 2
baz
CA".Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList().Skip(1);

      var output = Common.CaseLineForNFromSecondVal(inputFile);

      output.Count().Should().Be(3);

      output.First().Count().Should().Be(4);
      output.Skip(1).First().Count().Should().Be(5);
      output.Skip(2).First().Count().Should().Be(3);

      output.First().First().Should().Be("3 3");
      output.First().Skip(1).First().Should().Be("foo");
      output.First().Skip(2).First().Should().Be("?C?");
      output.First().Skip(3).First().Should().Be("??J");

      output.Skip(1).First().First().Should().Be("3 4");
      output.Skip(1).First().Skip(1).First().Should().Be("bar");
      output.Skip(1).First().Skip(2).First().Should().Be("CODE");
      output.Skip(1).First().Skip(3).First().Should().Be("????");
      output.Skip(1).First().Skip(4).First().Should().Be("?JAM");

      output.Skip(2).First().First().Should().Be("4 2");
      output.Skip(2).First().Skip(1).First().Should().Be("baz");
      output.Skip(2).First().Skip(2).First().Should().Be("CA");
    }

    [Test]
    public static void CustomFormat()
    {
      var inputFile =
@"3
1 3 3 7
foo
?C?
??J
foo
?C?
??J
1 3 4 6
bar
CODE
????
?JAM
foo
?C?
??J
1 4 2 4
bar
CODE
????
?JAM
baz
CA".Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList().Skip(1);

      var output = Common.CaseLineSplitter(inputFile, "-1 0 1 -1", (lineCount, args) => { return lineCount < args[0] + args[1]; });

      output.Count().Should().Be(3);

      output.First().Count().Should().Be(7);
      output.Skip(1).First().Count().Should().Be(8);
      output.Skip(2).First().Count().Should().Be(7);

      output.First().First().Should().Be("1 3 3 7");
      output.First().Skip(1).First().Should().Be("foo");
      output.First().Skip(2).First().Should().Be("?C?");
      output.First().Skip(3).First().Should().Be("??J");
      output.First().Skip(4).First().Should().Be("foo");
      output.First().Skip(5).First().Should().Be("?C?");
      output.First().Skip(6).First().Should().Be("??J");

      output.Skip(1).First().First().Should().Be("1 3 4 6");
      output.Skip(1).First().Skip(1).First().Should().Be("bar");
      output.Skip(1).First().Skip(2).First().Should().Be("CODE");
      output.Skip(1).First().Skip(3).First().Should().Be("????");
      output.Skip(1).First().Skip(4).First().Should().Be("?JAM");
      output.Skip(1).First().Skip(5).First().Should().Be("foo");
      output.Skip(1).First().Skip(6).First().Should().Be("?C?");
      output.Skip(1).First().Skip(7).First().Should().Be("??J");

      output.Skip(2).First().First().Should().Be("1 4 2 4");
      output.Skip(2).First().Skip(1).First().Should().Be("bar");
      output.Skip(2).First().Skip(2).First().Should().Be("CODE");
      output.Skip(2).First().Skip(3).First().Should().Be("????");
      output.Skip(2).First().Skip(4).First().Should().Be("?JAM");
      output.Skip(2).First().Skip(5).First().Should().Be("baz");
      output.Skip(2).First().Skip(6).First().Should().Be("CA");
    }
  }
}
