﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CoreTraining
{
  class CaseInput
  {
    internal CaseInput(IEnumerable<string> linesIn)
    {
      var lines = linesIn.ToList();
      var NKline = lines.First();
      var split = NKline.Split(' ');
      N = int.Parse(split[0]);
      K = int.Parse(split[1]);

      U = decimal.Parse(lines[1]);

      var lastLine = lines.Last();
      Cores = lastLine.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(decimal.Parse).Select((val, index) => new Core(val, index)).ToArray();
    }

    internal int N;
    internal int K;
    internal decimal U;
    internal Core[] Cores;
  }

  class Core
  {
    internal Core(decimal success, int index)
    {
      Success = success;
      n = index;
    }

    public int n;
    public decimal Success;
    public decimal Failure { get { return 1 - Success; } }
  }

  class KnownCoresInput
  {
    internal KnownCoresInput(CaseInput input, List<int> targetCores)
    {
      K = input.K;
      U = input.U;

      Cores = input.Cores.Where(core => targetCores.Contains(core.n)).ToArray();
    }

    internal int K;
    internal decimal U;
    internal Core[] Cores;
  }

  class CaseOutput
  {
    internal CaseOutput(decimal success)
    {
      Success = success;
    }

    internal decimal Success;

    public override string ToString()
    {
      return Success.ToString("0.#######");
    }
  }

}
