﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text.RegularExpressions;

namespace CoreTraining
{
  /*
   * TODO:
   *   - Namespace
   *   - Copy in/out files.
   *   - References to Common and testing Frameworks
   *   - CodeJam Reference to here.
   *   - Program redirect to here.
   */

  public class CaseSolver
  {
    private static string subFolderName = @"CoreTraining";
    private static int numberOfCases;

    public static void Run()
    {
      var lines = Common.Common.ReadStringInput(subFolderName, out numberOfCases).ToList();
      var cases = Common.Common.CaseLineSplitter(lines, "", (args) => 3 ).ToArray();
      var results = new List<string>();

      for (int ii = 0; ii < numberOfCases; ii++)
      {
        var parsedCase = new CaseInput(cases[ii]);
        var solver = new CaseSolver(parsedCase);
        var result = solver.Solve();

        var resultText = result.ToString();

        results.Add(string.Format("Case #{0}: {1}", ii + 1, resultText));
      }

      Common.Common.WriteOutput(subFolderName, results);
    }



    private CaseInput input;

    internal CaseSolver(CaseInput inputCase)
    {
      input = inputCase;
    }

    internal CaseOutput Solve()
    {
      if (input.N == input.K)
      {
        trainToOptimalPosition(new KnownCoresInput(input, Enumerable.Range(0, input.K).ToList()));
        var solution = EvaluateInputSuccessRate(input.Cores);

        return new CaseOutput(solution);
      }
      else
      {
        var selectedCores = input.Cores.OrderByDescending(core => core.Success).Take(input.K).Select(core => core.n).ToList();
        var newInput = new KnownCoresInput(input, selectedCores);
        trainToOptimalPosition(newInput);
        var solution = EvaluateInputSuccessRate(newInput.Cores);

        return new CaseOutput(solution);
      }
    }

    internal void trainToOptimalPosition(KnownCoresInput newInput)
    {
      var coreQ = new Queue<Core>(newInput.Cores.OrderBy(core => core.Success));
      var remainingTraining = newInput.U;

      if (!coreQ.Any())
      {
        throw new Exception();
      }

      var trainingCoreSet = new List<Core>();
      trainingCoreSet.Add(coreQ.Dequeue());

      while (remainingTraining > 0 && coreQ.Any())
      {

        var nextCore = coreQ.Peek();
        var successDiff = nextCore.Success - trainingCoreSet.First().Success;

        if (successDiff != 0)
        {
          remainingTraining = TrainCoresByAmountOrMax(trainingCoreSet, successDiff, remainingTraining);
        }

        trainingCoreSet.Add(coreQ.Dequeue());
      }

      if (remainingTraining > 0)
      {
        var currentSuccess = trainingCoreSet.First().Success;
        TrainCoresByAmountOrMax(trainingCoreSet, 1 - currentSuccess, remainingTraining);
      }
    }

    private static decimal TrainCoresByAmountOrMax(List<Core> trainingCoreSet, decimal trainingAmountGoal, decimal totalTrainingLimit)
    {
      var trainingCoreCount = trainingCoreSet.Count();
      var fullTrainCost = trainingAmountGoal * trainingCoreCount;

      if (fullTrainCost <= totalTrainingLimit)
      {
        TrainCoresByAmount(trainingCoreSet, trainingAmountGoal);
        totalTrainingLimit -= fullTrainCost;
      }
      else
      {
        TrainCoresByAmount(trainingCoreSet, totalTrainingLimit / trainingCoreCount);
        totalTrainingLimit = 0;
      }
      return totalTrainingLimit;
    }

    private static void TrainCoresByAmount(List<Core> trainingCoreSet, decimal amount)
    {
      foreach (var core in trainingCoreSet)
      {
        core.Success += amount;
      }
    }

    private decimal EvaluateInputSuccessRate(IEnumerable<Core> selectedCores)
    {
      if (input.N == input.K)
      {
        return input.Cores.Aggregate(1.0m, (acc, core) => acc * core.Success);
      }
      else
      {
        return selectedCores.Aggregate(1.0m, (acc, core) => acc * core.Success);
      }
    }


  }
}