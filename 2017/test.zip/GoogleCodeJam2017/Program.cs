﻿namespace GoogleCodeJam2017
{
  class Program
  {
    static void Main()
    {
      CoreTraining.CaseSolver.Run();
    }
  }
}
