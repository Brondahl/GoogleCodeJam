﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Parenting
{
  class CaseInput
  {
    internal CaseInput(IEnumerable<string> linesIn)
    {
      var lines = linesIn.ToList();
      var ALine = lines.First();
      var split = ALine.Split(' ');
      AC = long.Parse(split[0]);
      AJ = long.Parse(split[1]);

      PancakeHeights = new long[N];
      PancakeRadii = new long[N];
      PancakeSideAreaOverPi = new long[N];

      var CLines = lines.Skip(1).Take((int)AC).ToArray();
      var pancakeData = CLines.Select(line =>
        line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(long.Parse).ToArray()
      ).ToArray();

      for (int i = 0; i < N; i++)
      {
        PancakeRadii[i] = pancakeData[i][0];
        PancakeHeights[i] = pancakeData[i][1];
        PancakeSideAreaOverPi[i] = 2 * PancakeRadii[i] * PancakeHeights[i];
      }
    }

    //internal CaseInput(CaseInput baseCase)
    //{
    //  N = baseCase.N;
    //  R = baseCase.R;
    //  O = baseCase.O;
    //  Y = baseCase.Y;
    //  G = baseCase.G;
    //  B = baseCase.B;
    //  V = baseCase.V;
    //}

    internal long AC;
    internal long AJ;
    internal long K;
    internal long[] CiStart;
    internal long[] JiStart;
    internal long[] PancakeSideAreaOverPi;

  }

  class CaseOutput
  {
    internal CaseOutput(double area)
    {
      Area = area;
    }

    internal double Area;

    public override string ToString()
    {
      return Area.ToString("0.#######");
    }
  }

}
